import com.mtz2bak.core.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.zip.*;

/** Builds a synthetic .mtz, converts it, and re-verifies the result. Fails the CI build if broken. */
public class SelfTest {
    public static void main(String[] a) throws Exception {
        File dir = new File(System.getProperty("java.io.tmpdir"), "mtz2bak-selftest");
        dir.mkdirs();
        File mtz = new File(dir, "t.mtz");
        String desc = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><theme><version><![CDATA[1.0]]></version><uiVersion>15</uiVersion>"
                + "<author><![CDATA[Tester]]></author><title><![CDATA[\u0627\u062e\u062a\u0628\u0627\u0631]]></title>"
                + "<titles><title locale=\"zh_CN\"><![CDATA[\u6d4b\u8bd5]]></title></titles></theme>";
        try (ZipOutputStream z = new ZipOutputStream(new FileOutputStream(mtz))) {
            put(z, "description.xml", desc.getBytes(StandardCharsets.UTF_8));
            put(z, "icons", new byte[70000]);
            put(z, "lockscreen", "x".getBytes());
            put(z, "com.android.systemui", new byte[512]);
            put(z, "wallpaper/default_wallpaper.jpg", new byte[1000]);
            put(z, "preview/preview_icons_0.jpg", new byte[300]);
            put(z, "preview/preview_launcher_0.jpg", new byte[10]);
        }
        File out = new File(dir, "t.bak");
        try (OutputStream o = new FileOutputStream(out)) {
            BakBuilder.Result r = BakBuilder.build(mtz, "fallback", o, BakBuilder.ManifestInfo.defaults(), null);
            if (r.components.size() != 4) throw new AssertionError("components: " + r.components);
        }
        String s = BakVerifier.verify(out);
        System.out.println("SelfTest OK: " + s);
        // corrupt one byte in the middle -> verifier must reject
        byte[] all = java.nio.file.Files.readAllBytes(out.toPath());
        all[all.length / 2] ^= 0x55;
        File bad = new File(dir, "bad.bak");
        java.nio.file.Files.write(bad.toPath(), all);
        try { BakVerifier.verify(bad); throw new AssertionError("corruption not detected"); }
        catch (IOException expected) { System.out.println("Corruption detected as expected: " + expected.getMessage()); }
    }
    private static void put(ZipOutputStream z, String n, byte[] d) throws IOException {
        z.putNextEntry(new ZipEntry(n)); z.write(d); z.closeEntry();
    }
}
