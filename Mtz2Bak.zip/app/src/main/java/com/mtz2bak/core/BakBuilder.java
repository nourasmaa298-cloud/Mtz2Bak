package com.mtz2bak.core;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Converts a Xiaomi/MIUI/HyperOS theme (.mtz) into a "Themes(com.android.thememanager).bak"
 * file that the system Backup app can restore. Pure Java, no Android dependencies, so it can be
 * unit-tested on a desktop JVM.
 *
 * Layout reverse-engineered from a real device-made backup:
 *   "MIUI BACKUP" header + "ANDROID BACKUP" header + uncompressed ustar tar:
 *   apps/com.android.thememanager/_manifest
 *   apps/com.android.thememanager/ef/MIUI/theme/.data/meta/theme/<themeId>.mrm
 *   apps/com.android.thememanager/ef/MIUI/theme/.data/meta/<code>/<compId>.mrm
 *   apps/com.android.thememanager/ef/MIUI/theme/.data/content/theme/<themeId>.mrc   (empty)
 *   apps/com.android.thememanager/ef/MIUI/theme/.data/content/<code>/<compId>.mrc   (= mtz entry bytes)
 *   apps/com.android.thememanager/ef/MIUI/theme/.data/preview/theme/<themeId>/<preview files>
 */
public final class BakBuilder {

    public static final String PKG = "com.android.thememanager";
    public static final String BAK_FILE_NAME = "Themes(com.android.thememanager).bak";

    /** Values for the adb-style _manifest entry. Should come from the installed Themes app. */
    public static final class ManifestInfo {
        public long versionCode = 2090308L;
        public int sdkInt = 36;
        public String installer = "com.miui.packageinstaller";
        public List<String> signaturesHex = new ArrayList<>();

        /** Defaults copied from a real HyperOS device backup (used only if the Themes app can't be queried). */
        public static ManifestInfo defaults() {
            ManifestInfo m = new ManifestInfo();
            m.signaturesHex.add("3082046c30820354a003020102020900e552a8ecb9011b7c300d06092a864886f70d0101050500308180310b300906035504061302434e3110300e060355040813074265696a696e673110300e060355040713074265696a696e67310f300d060355040a13065869616f6d69310d300b060355040b13044d495549310d300b060355040313044d495549311e301c06092a864886f70d010901160f6d697569407869616f6d692e636f6d301e170d3131313230363033323632365a170d3339303432333033323632365a308180310b300906035504061302434e3110300e060355040813074265696a696e673110300e060355040713074265696a696e67310f300d060355040a13065869616f6d69310d300b060355040b13044d495549310d300b060355040313044d495549311e301c06092a864886f70d010901160f6d697569407869616f6d692e636f6d30820120300d06092a864886f70d01010105000382010d00308201080282010100c786568a9aff253ad74c5d3e6fbffa12fed44cd3244f18960ec5511bb551e413115197234845112cc3df9bbacd3e0f4b3528cd87ed397d577dc9008e9cbc6a25fc0664d3a3f440243786db8b250d40f6f148c9a3cd6fbc2dd8d24039bd6a8972a1bdee28c308798bfa9bb3b549877b10f98e265f118c05f264537d95e29339157b9d2a31485e0c823521cca6d0b721a8432600076d669e20ac43aa588b52c11c2a51f04c6bb31ad6ae8573991afe8e4957d549591fcb83ec62d1da35b1727dc6b63001a5ef387b5a7186c1e68da1325772b5307b1bc739ef236b9efe06d52dcaf1e32768e3403e55e3ec56028cf5680cfb33971ccf7870572bc47d3e3affa385020103a381e83081e5301d0603551d0e0416041491ae2f8c72e305f92aa9f7452e2a3160b841a15c3081b50603551d230481ad3081aa801491ae2f8c72e305f92aa9f7452e2a3160b841a15ca18186a48183308180310b300906035504061302434e3110300e060355040813074265696a696e673110300e060355040713074265696a696e67310f300d060355040a13065869616f6d69310d300b060355040b13044d495549310d300b060355040313044d495549311e301c06092a864886f70d010901160f6d697569407869616f6d692e636f6d820900e552a8ecb9011b7c300c0603551d13040530030101ff300d06092a864886f70d010105050003820101003b3a699ceb497300f2ab86cbd41c513440bf60aa5c43984eb1da140ef30544d9fbbb3733df24b26f2703d7ffc645bf598a5e6023596a947e91731542f2c269d0816a69c92df9bfe8b1c9bc3c54c46c12355bb4629fe6020ca9d15f8d6155dc5586f5616db806ecea2d06bd83e32b5f13f5a04fe3e5aa514f05df3d555526c63d3d62acf00adee894b923c2698dc571bc52c756ffa7a2221d834d10cb7175c864c30872fe217c31442dff0040a67a2fb1c8ba63eac2d5ba3d8e76b4ff2a49b0db8a33ef4ae0dd0a840dd2a8714cb5531a56b786819ec9eb1051d91b23fde06bd9d0708f150c4f9efe6a416ca4a5e0c23a952af931ad3579fb4a8b19de98f64bd9");
            return m;
        }
    }

    public static final class Result {
        public String title;
        public String themeId;
        public final List<String> components = new ArrayList<>();
        public final List<String> warnings = new ArrayList<>();
        public int previewCount;
        public long bytesWritten;
    }

    public interface Progress { void onStep(String message); }

    // ---- mtz entry -> MIUI resource code -------------------------------------------------
    private static final Map<String, String> SPECIAL = new LinkedHashMap<>();
    static {
        SPECIAL.put("lockscreen", "lockstyle");
        SPECIAL.put("wallpaper/default_lock_wallpaper.jpg", "lockscreen");
        SPECIAL.put("wallpaper/default_wallpaper.jpg", "wallpaper");
        SPECIAL.put("framework-res", "framework");
        SPECIAL.put("com.miui.home", "launcher");
        SPECIAL.put("com.android.systemui", "statusbar");
        SPECIAL.put("com.android.mms", "mms");
        SPECIAL.put("com.android.contacts", "contact");
    }
    private static final SafeName SAFE = new SafeName();
    private static final class SafeName {
        boolean ok(String s) {
            if (s.isEmpty() || s.length() > 80) return false;
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                boolean good = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')
                        || c == '.' || c == '_' || c == '-';
                if (!good) return false;
            }
            return !s.startsWith(".");
        }
    }

    static String codeFor(String entryName) {
        String s = SPECIAL.get(entryName);
        if (s != null) return s;
        if (entryName.equals("description.xml")) return null;
        if (entryName.indexOf('/') >= 0) return null;        // other sub-folders: not a component file
        return SAFE.ok(entryName) ? entryName : null;
    }

    private static String previewPrefix(String code) {
        if (code.equals("lockstyle") || code.equals("lockscreen")) return "preview_lockscreen";
        if (code.equals("wallpaper")) return null;
        return "preview_" + code;
    }

    // ---- description.xml ---------------------------------------------------------------
    private static final class Desc {
        String version = "1.0";
        int platform = 15;
        String adapter = null;
        Map<String, String> authors = new LinkedHashMap<>();
        Map<String, String> designers = new LinkedHashMap<>();
        Map<String, String> titles = new LinkedHashMap<>();
        Map<String, String> descriptions = new LinkedHashMap<>();
    }

    private static Desc parseDesc(byte[] xml, String fallbackTitle, List<String> warnings) {
        Desc d = new Desc();
        try {
            DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
            DocumentBuilder b = f.newDocumentBuilder();
            Document doc = b.parse(new ByteArrayInputStream(xml));
            Element root = doc.getDocumentElement();
            String v = childText(root, "version");
            if (v != null && !v.isEmpty()) d.version = v;
            String ui = childText(root, "uiVersion");
            if (ui != null) { try { d.platform = Integer.parseInt(ui.trim()); } catch (Exception ignore) { } }
            String ad = childText(root, "miuiAdapterVersion");
            if (ad != null && !ad.isEmpty()) d.adapter = ad;
            fill(root, "author", "authors", d.authors);
            fill(root, "designer", "designers", d.designers);
            fill(root, "title", "titles", d.titles);
            fill(root, "description", "descriptions", d.descriptions);
        } catch (Exception e) {
            warnings.add("description.xml could not be parsed: " + e.getMessage());
        }
        if (!d.titles.containsKey("fallback")) d.titles.put("fallback", fallbackTitle);
        if (!d.authors.containsKey("fallback")) d.authors.put("fallback", "");
        if (!d.designers.containsKey("fallback")) d.designers.put("fallback", d.authors.get("fallback"));
        if (!d.descriptions.containsKey("fallback")) d.descriptions.put("fallback", "");
        return d;
    }

    private static String childText(Element parent, String tag) {
        for (Node n = parent.getFirstChild(); n != null; n = n.getNextSibling()) {
            if (n.getNodeType() == Node.ELEMENT_NODE && n.getNodeName().equals(tag)) return n.getTextContent();
        }
        return null;
    }

    private static void fill(Element root, String single, String plural, Map<String, String> out) {
        for (Node n = root.getFirstChild(); n != null; n = n.getNextSibling()) {
            if (n.getNodeType() != Node.ELEMENT_NODE) continue;
            if (n.getNodeName().equals(single)) {
                out.put("fallback", n.getTextContent());
            } else if (n.getNodeName().equals(plural)) {
                NodeList kids = n.getChildNodes();
                for (int i = 0; i < kids.getLength(); i++) {
                    Node k = kids.item(i);
                    if (k.getNodeType() == Node.ELEMENT_NODE && k.getNodeName().equals(single)) {
                        String loc = ((Element) k).getAttribute("locale");
                        if (loc != null && !loc.isEmpty()) out.put(loc, k.getTextContent());
                    }
                }
            }
        }
    }

    // ---- main entry point -------------------------------------------------------------
    public static Result build(File mtz, String fallbackTitle, OutputStream rawOut, ManifestInfo mi, Progress progress)
            throws IOException {
        Result res = new Result();
        long mtzSize = mtz.length();
        if (progress != null) progress.onStep("Reading theme package");
        String mtzSha1 = sha1Of(mtz);

        try (ZipFile zip = new ZipFile(mtz)) {
            ZipEntry descEntry = zip.getEntry("description.xml");
            if (descEntry == null) throw new IOException("description.xml not found: this is not a valid .mtz theme");
            Desc desc = parseDesc(readAll(zip, descEntry), fallbackTitle, res.warnings);
            res.title = desc.titles.get("fallback");

            // collect components
            LinkedHashMap<String, ZipEntry> comps = new LinkedHashMap<>();
            List<ZipEntry> previews = new ArrayList<>();
            for (Enumeration<? extends ZipEntry> en = zip.entries(); en.hasMoreElements(); ) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory()) continue;
                String name = e.getName();
                if (name.startsWith("preview/") && name.indexOf('/', 8) < 0 && name.length() > 8) { previews.add(e); continue; }
                String code = codeFor(name);
                if (code == null) {
                    if (!name.equals("description.xml")) res.warnings.add("Skipped unsupported entry: " + name);
                    continue;
                }
                if (comps.containsKey(code)) { res.warnings.add("Duplicate component " + code + " ignored"); continue; }
                if (e.getSize() < 0) throw new IOException("Unknown size for " + name);
                comps.put(code, e);
            }
            if (comps.isEmpty()) throw new IOException("No theme components found inside the .mtz");
            previews.sort(Comparator.comparing(ZipEntry::getName));
            res.previewCount = previews.size();

            String themeId = UUID.randomUUID().toString();
            String assemblyId = UUID.randomUUID().toString();
            res.themeId = themeId;
            Map<String, String> compIds = new LinkedHashMap<>();
            for (String c : comps.keySet()) compIds.put(c, UUID.randomUUID().toString());
            Map<String, String> compSha1 = new LinkedHashMap<>();
            for (Map.Entry<String, ZipEntry> me : comps.entrySet()) {
                if (progress != null) progress.onStep("Hashing " + me.getKey());
                compSha1.put(me.getKey(), sha1Of(zip, me.getValue()));
            }
            Set<String> previewNames = new LinkedHashSet<>();
            for (ZipEntry p : previews) previewNames.add(p.getName().substring(8));

            // ---- write the file
            CountingOutputStream out = new CountingOutputStream(new BufferedOutputStream(rawOut, 1 << 16));
            out.write(("MIUI BACKUP\n2\n" + PKG + " Themes\n-1\n0\n").getBytes(StandardCharsets.ISO_8859_1));
            out.write("ANDROID BACKUP\n5\n0\nnone\n".getBytes(StandardCharsets.ISO_8859_1));
            Tar tar = new Tar(out);

            String base = "apps/" + PKG + "/";
            tar.file(base + "_manifest", manifestBytes(mi), 0600);

            String data = base + "ef/MIUI/theme/.data/";
            for (String d : new String[]{"ef/MIUI", "ef/MIUI/theme", "ef/MIUI/theme/.data", "ef/MIUI/theme/.data/meta",
                    "ef/MIUI/theme/.data/content", "ef/MIUI/theme/.data/preview", "ef/MIUI/theme/.data/preview/theme"}) {
                tar.dir(base + d);
            }
            tar.dir(data + "meta/theme");
            tar.dir(data + "content/theme");
            tar.dir(data + "preview/theme/" + themeId);
            for (String c : comps.keySet()) { tar.dir(data + "meta/" + c); tar.dir(data + "content/" + c); }

            // component meta
            List<String> orderedPreviews = orderPreviews(previewNames);
            for (Map.Entry<String, ZipEntry> me : comps.entrySet()) {
                String code = me.getKey();
                String pfx = previewPrefix(code);
                List<String> pv = new ArrayList<>();
                if (pfx != null) for (String n : previewNames) if (n.startsWith(pfx)) pv.add(n);
                Collections.sort(pv);
                Map<String, Object> m = metaMap(desc, compIds.get(code), assemblyId, compSha1.get(code),
                        me.getValue().getSize(), pv);
                List<Object> parents = new ArrayList<>();
                parents.add(subRef(themeId, "theme"));
                m.put("parentResources", parents);
                tar.file(data + "meta/" + code + "/" + compIds.get(code) + ".mrm", Json.write(m).getBytes(StandardCharsets.UTF_8), 0660);
            }
            // theme meta
            Map<String, Object> tm = metaMap(desc, themeId, assemblyId, mtzSha1, mtzSize, orderedPreviews);
            List<Object> subs = new ArrayList<>();
            for (String c : comps.keySet()) subs.add(subRef(compIds.get(c), c));
            tm.put("subResources", subs);
            // Same flags a real store theme carries (price 0, bought) - copied from a device-made backup.
            tm.put("price", 0);
            Object adapter = tm.remove("miuiAdapterVersion");
            tm.put("bought", true);
            tm.put("check_bought", true);
            tm.put("miuiAdapterVersion", adapter);
            tar.file(data + "meta/theme/" + themeId + ".mrm", Json.write(tm).getBytes(StandardCharsets.UTF_8), 0660);

            // content
            tar.file(data + "content/theme/" + themeId + ".mrc", new byte[0], 0660);
            for (Map.Entry<String, ZipEntry> me : comps.entrySet()) {
                if (progress != null) progress.onStep("Packing " + me.getKey());
                tar.fileFromZip(data + "content/" + me.getKey() + "/" + compIds.get(me.getKey()) + ".mrc", zip, me.getValue(), 0660);
                res.components.add(me.getKey());
            }
            // previews
            for (ZipEntry p : previews) {
                tar.fileFromZip(data + "preview/theme/" + themeId + "/" + p.getName().substring(8), zip, p, 0660);
            }
            tar.finish();
            out.flush();
            res.bytesWritten = out.count;
        }
        return res;
    }

    private static List<String> orderPreviews(Set<String> names) {
        String[] prio = {"preview_lockscreen", "preview_launcher", "preview_statusbar", "preview_contact",
                "preview_mms", "preview_icons", "preview_clock"};
        List<String> out = new ArrayList<>();
        Set<String> left = new TreeSet<>(names);
        for (String p : prio) {
            for (Iterator<String> it = left.iterator(); it.hasNext(); ) {
                String n = it.next();
                if (n.startsWith(p)) { out.add(n); it.remove(); }
            }
        }
        out.addAll(left);
        return out;
    }

    private static Map<String, Object> subRef(String id, String code) {
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("localId", id);
        r.put("resourceCode", code);
        r.put("extraMeta", new LinkedHashMap<String, Object>());
        r.put("metaPath", null);
        r.put("contentPath", null);
        return r;
    }

    private static Map<String, Object> metaMap(Desc d, String localId, String assemblyId, String hash, long size, List<String> previews) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("localId", localId);
        m.put("onlineId", null);
        m.put("assemblyId", assemblyId);
        m.put("productId", null);
        m.put("hash", hash);
        m.put("platform", d.platform);
        m.put("size", size);
        m.put("updatedTime", 0);
        m.put("version", d.version);
        m.put("authors", new LinkedHashMap<>(d.authors));
        m.put("designers", new LinkedHashMap<>(d.designers));
        m.put("titles", new LinkedHashMap<>(d.titles));
        m.put("descriptions", new LinkedHashMap<>(d.descriptions));
        Map<String, Object> th = new LinkedHashMap<>(); th.put("fallback", new ArrayList<Object>(previews));
        Map<String, Object> pr = new LinkedHashMap<>(); pr.put("fallback", new ArrayList<Object>(previews));
        m.put("builtInThumbnails", th);
        m.put("builtInPreviews", pr);
        m.put("thumbnails", new ArrayList<Object>());
        m.put("previews", new ArrayList<Object>());
        m.put("parentResources", new ArrayList<Object>());
        m.put("subResources", new ArrayList<Object>());
        m.put("extraMeta", new LinkedHashMap<String, Object>());
        m.put("metaPath", null);
        m.put("contentPath", null);
        m.put("rightsPath", null);
        m.put("screenRatio", null);
        m.put("supportHomeSearchBar", false);
        m.put("packageVersion", null);
        m.put("packageName", null);
        m.put("officialIcons", false);
        m.put("iconsCount", null);
        m.put("fontWeight", null);
        m.put("price", -1);
        m.put("isBackUpVersion", false);
        m.put("themeType", 0);
        m.put("miuiAdapterVersion", d.adapter);
        return m;
    }

    public static byte[] manifestBytes(ManifestInfo mi) {
        StringBuilder sb = new StringBuilder();
        sb.append("1\n").append(PKG).append('\n').append(mi.versionCode).append('\n').append(mi.sdkInt).append('\n');
        sb.append(mi.installer == null ? "" : mi.installer).append('\n');
        sb.append("0\n").append(mi.signaturesHex.size()).append('\n');
        for (String s : mi.signaturesHex) sb.append(s).append('\n');
        return sb.toString().getBytes(StandardCharsets.ISO_8859_1);
    }

    // ---- helpers ----------------------------------------------------------------------
    private static byte[] readAll(ZipFile z, ZipEntry e) throws IOException {
        try (InputStream in = z.getInputStream(e)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toByteArray();
        }
    }

    private static String sha1Of(File f) throws IOException {
        try (InputStream in = new FileInputStream(f)) { return sha1(in); }
    }

    private static String sha1Of(ZipFile z, ZipEntry e) throws IOException {
        try (InputStream in = z.getInputStream(e)) { return sha1(in); }
    }

    private static String sha1(InputStream in) throws IOException {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] buf = new byte[1 << 16]; int n;
            while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
            return hex(md.digest());
        } catch (java.security.NoSuchAlgorithmException ex) { throw new IOException(ex); }
    }

    public static String hex(byte[] b) {
        char[] H = "0123456789abcdef".toCharArray();
        char[] o = new char[b.length * 2];
        for (int i = 0; i < b.length; i++) { o[2 * i] = H[(b[i] >> 4) & 15]; o[2 * i + 1] = H[b[i] & 15]; }
        return new String(o);
    }

    private static final class CountingOutputStream extends FilterOutputStream {
        long count;
        CountingOutputStream(OutputStream o) { super(o); }
        @Override public void write(int b) throws IOException { out.write(b); count++; }
        @Override public void write(byte[] b, int off, int len) throws IOException { out.write(b, off, len); count += len; }
    }

    // ---- ustar writer -----------------------------------------------------------------
    private static final class Tar {
        private final OutputStream out;
        private final long mtime = System.currentTimeMillis() / 1000L;
        Tar(OutputStream o) { out = o; }

        void dir(String path) throws IOException {
            header(path.endsWith("/") ? path.substring(0, path.length() - 1) : path, 0, '5', 02770);
        }

        void file(String path, byte[] data, int mode) throws IOException {
            header(path, data.length, '0', mode);
            out.write(data);
            pad(data.length);
        }

        void fileFromZip(String path, ZipFile z, ZipEntry e, int mode) throws IOException {
            long size = e.getSize();
            header(path, size, '0', mode);
            long copied = 0;
            try (InputStream in = z.getInputStream(e)) {
                byte[] buf = new byte[1 << 16]; int n;
                while ((n = in.read(buf)) > 0) { out.write(buf, 0, n); copied += n; }
            }
            if (copied != size) throw new IOException("Size mismatch for " + e.getName());
            pad(size);
        }

        void finish() throws IOException { out.write(new byte[1024]); }

        private void pad(long size) throws IOException {
            int r = (int) (size % 512);
            if (r != 0) out.write(new byte[512 - r]);
        }

        private void header(String path, long size, char type, int mode) throws IOException {
            byte[] full = path.getBytes(StandardCharsets.UTF_8);
            String name = path, prefix = "";
            if (full.length > 100) {
                int cut = -1;
                for (int i = path.length() - 1; i > 0; i--) {
                    if (path.charAt(i) == '/') {
                        String p = path.substring(0, i), n = path.substring(i + 1);
                        if (p.getBytes(StandardCharsets.UTF_8).length <= 155 && n.getBytes(StandardCharsets.UTF_8).length <= 100) { cut = i; break; }
                    }
                }
                if (cut < 0) throw new IOException("Path too long for tar: " + path);
                prefix = path.substring(0, cut);
                name = path.substring(cut + 1);
            }
            byte[] h = new byte[512];
            put(h, 0, name, 100);
            putOct(h, 100, mode, 7);
            putOct(h, 108, 0, 7);
            putOct(h, 116, 0, 7);
            putOct(h, 124, size, 11);
            putOct(h, 136, mtime, 11);
            Arrays.fill(h, 148, 156, (byte) ' ');
            h[156] = (byte) type;
            put(h, 257, "ustar", 6);
            h[263] = '0'; h[264] = '0';
            put(h, 345, prefix, 155);
            long sum = 0;
            for (byte b : h) sum += (b & 0xff);
            String cs = String.format("%06o", sum);
            for (int i = 0; i < 6; i++) h[148 + i] = (byte) cs.charAt(i);
            h[154] = 0; h[155] = ' ';
            out.write(h);
        }

        private static void put(byte[] h, int off, String s, int max) {
            byte[] b = s.getBytes(StandardCharsets.UTF_8);
            System.arraycopy(b, 0, h, off, Math.min(b.length, max));
        }

        private static void putOct(byte[] h, int off, long v, int digits) {
            String s = Long.toOctalString(v);
            while (s.length() < digits) s = "0" + s;
            for (int i = 0; i < digits; i++) h[off + i] = (byte) s.charAt(i);
        }
    }

    // ---- tiny JSON writer ---------------------------------------------------------------
    static final class Json {
        static String write(Object o) { StringBuilder sb = new StringBuilder(); w(sb, o, 0); return sb.toString(); }

        @SuppressWarnings("unchecked")
        private static void w(StringBuilder sb, Object o, int ind) {
            if (o == null) sb.append("null");
            else if (o instanceof String) str(sb, (String) o);
            else if (o instanceof Number || o instanceof Boolean) sb.append(o);
            else if (o instanceof Map) {
                Map<String, Object> m = (Map<String, Object>) o;
                if (m.isEmpty()) { sb.append("{}"); return; }
                sb.append("{\n");
                int i = 0;
                for (Map.Entry<String, Object> e : m.entrySet()) {
                    indent(sb, ind + 1); str(sb, e.getKey()); sb.append(": "); w(sb, e.getValue(), ind + 1);
                    if (++i < m.size()) sb.append(',');
                    sb.append('\n');
                }
                indent(sb, ind); sb.append('}');
            } else if (o instanceof List) {
                List<Object> l = (List<Object>) o;
                if (l.isEmpty()) { sb.append("[]"); return; }
                sb.append("[\n");
                for (int i = 0; i < l.size(); i++) {
                    indent(sb, ind + 1); w(sb, l.get(i), ind + 1);
                    if (i + 1 < l.size()) sb.append(',');
                    sb.append('\n');
                }
                indent(sb, ind); sb.append(']');
            } else str(sb, o.toString());
        }

        private static void indent(StringBuilder sb, int n) { for (int i = 0; i < n; i++) sb.append("  "); }

        private static void str(StringBuilder sb, String s) {
            sb.append('"');
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                switch (c) {
                    case '"': sb.append("\\\""); break;
                    case '\\': sb.append("\\\\"); break;
                    case '\n': sb.append("\\n"); break;
                    case '\r': sb.append("\\r"); break;
                    case '\t': sb.append("\\t"); break;
                    default:
                        if (c < 0x20) sb.append(String.format("\\u%04x", (int) c)); else sb.append(c);
                }
            }
            sb.append('"');
        }
    }
}
