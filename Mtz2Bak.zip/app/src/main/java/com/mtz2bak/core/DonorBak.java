package com.mtz2bak.core;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.InflaterInputStream;

/**
 * Reads a REAL Themes backup (made by the phone / the Backup app) and, if it contains the very same
 * theme file (same SHA-1), returns that theme's genuine identity: its metadata, the Xiaomi-issued
 * rights file (.mra) and the import records. These are copied verbatim - nothing is forged.
 */
public final class DonorBak {

    public static final class Match {
        public String themeId, onlineId, assemblyId;
        public byte[] themeMeta;
        public final Map<String, String> compIds = new LinkedHashMap<>();   // code -> localId
        public final Map<String, byte[]> compMetas = new LinkedHashMap<>(); // code -> mrm bytes
        public final Map<String, String> compHash = new LinkedHashMap<>();  // code -> sha1 in donor meta
        public String rightsName;
        public byte[] rights;
        public final Map<String, byte[]> imports = new LinkedHashMap<>();   // file name -> bytes
    }

    private static final Pattern META = Pattern.compile(".*/\\.data/meta/([^/]+)/([^/]+)\\.mrm");
    private static final Pattern RIGHTS = Pattern.compile(".*/\\.data/rights/theme/([^/]+\\.mra)");
    private static final Pattern IMPORT = Pattern.compile(".*/\\.data/import/theme/([^/]+)");
    private static final long MAX_SMALL = 4L << 20;

    public static Match find(File donor, String mtzSha1, List<String> warnings) throws IOException {
        Map<String, byte[]> metas = new LinkedHashMap<>();   // "code/id" -> bytes
        Map<String, byte[]> rights = new LinkedHashMap<>();
        Map<String, byte[]> imports = new LinkedHashMap<>();

        try (InputStream raw = new BufferedInputStream(new FileInputStream(donor), 1 << 16)) {
            List<String> hdr = new ArrayList<>();
            while (true) {
                String line = readLine(raw);
                hdr.add(line);
                if (line.equals("none") || hdr.size() > 14) break;
            }
            if (!hdr.get(hdr.size() - 1).equals("none")) throw new IOException("Not an Android/MIUI backup file");
            int ab = hdr.indexOf("ANDROID BACKUP");
            if (ab < 0 || ab + 2 >= hdr.size()) throw new IOException("Not an Android/MIUI backup file");
            boolean compressed = hdr.get(ab + 2).equals("1");
            InputStream in = compressed ? new BufferedInputStream(new InflaterInputStream(raw), 1 << 16) : raw;

            byte[] h = new byte[512];
            while (true) {
                readFully(in, h);
                boolean zero = true;
                for (byte b : h) if (b != 0) { zero = false; break; }
                if (zero) break;
                String name = cstr(h, 0, 100), prefix = cstr(h, 345, 155);
                String full = prefix.isEmpty() ? name : prefix + "/" + name;
                long size = parseOct(h, 124, 11);
                char type = (char) h[156];
                long padded = size + ((512 - size % 512) % 512);
                if (type != '0' && type != 0) { skip(in, padded); continue; }
                Matcher mm = META.matcher(full), rm = RIGHTS.matcher(full), im = IMPORT.matcher(full);
                if (size <= MAX_SMALL && (mm.matches() || rm.matches() || im.matches())) {
                    byte[] b = new byte[(int) size];
                    readFully(in, b);
                    skip(in, padded - size);
                    if (mm.matches()) metas.put(mm.group(1) + "/" + mm.group(2), b);
                    else if (rm.matches()) rights.put(rm.group(1), b);
                    else imports.put(im.group(1), b);
                } else {
                    skip(in, padded);
                }
            }
        }

        // find the theme-level meta whose hash is this .mtz
        for (Map.Entry<String, byte[]> e : metas.entrySet()) {
            if (!e.getKey().startsWith("theme/")) continue;
            Object o;
            try { o = MiniJson.parse(new String(e.getValue(), StandardCharsets.UTF_8)); }
            catch (RuntimeException ex) { continue; }
            if (!(o instanceof Map)) continue;
            @SuppressWarnings("unchecked") Map<String, Object> t = (Map<String, Object>) o;
            if (!mtzSha1.equals(t.get("hash"))) continue;

            Match m = new Match();
            m.themeId = (String) t.get("localId");
            m.onlineId = t.get("onlineId") instanceof String ? (String) t.get("onlineId") : null;
            m.assemblyId = t.get("assemblyId") instanceof String ? (String) t.get("assemblyId") : null;
            m.themeMeta = e.getValue();
            Object subs = t.get("subResources");
            if (subs instanceof List) {
                for (Object so : (List<?>) subs) {
                    if (!(so instanceof Map)) continue;
                    Map<?, ?> sm = (Map<?, ?>) so;
                    String code = (String) sm.get("resourceCode"), id = (String) sm.get("localId");
                    byte[] mb = metas.get(code + "/" + id);
                    if (code == null || id == null || mb == null) continue;
                    Object co = MiniJson.parse(new String(mb, StandardCharsets.UTF_8));
                    if (!(co instanceof Map)) continue;
                    m.compIds.put(code, id);
                    m.compMetas.put(code, mb);
                    m.compHash.put(code, String.valueOf(((Map<?, ?>) co).get("hash")));
                }
            }
            String[] candidates = {m.assemblyId == null ? null : m.assemblyId + ".mra", mtzSha1 + ".mra"};
            for (String c : candidates) {
                if (c != null && rights.containsKey(c)) {
                    String txt = new String(rights.get(c), StandardCharsets.UTF_8);
                    if (txt.contains(mtzSha1)) { m.rightsName = c; m.rights = rights.get(c); break; }
                }
            }
            if (m.onlineId != null) {
                for (String n : new String[]{m.onlineId, m.onlineId + ".mrm"}) {
                    if (imports.containsKey(n)) m.imports.put(n, imports.get(n));
                }
            }
            if (m.rights == null) warnings.add("The donor backup has this theme but no rights file for it");
            return m;
        }
        warnings.add("The donor backup does not contain this exact theme file");
        return null;
    }

    // ---- helpers
    private static String readLine(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = in.read()) != '\n') {
            if (c < 0 || sb.length() > 300) throw new IOException("Not an Android/MIUI backup file");
            sb.append((char) c);
        }
        return sb.toString();
    }

    private static void readFully(InputStream in, byte[] b) throws IOException {
        int o = 0;
        while (o < b.length) { int n = in.read(b, o, b.length - o); if (n < 0) throw new IOException("Unexpected end of donor file"); o += n; }
    }

    private static void skip(InputStream in, long n) throws IOException {
        byte[] buf = null;
        while (n > 0) {
            long s = in.skip(n);
            if (s <= 0) {
                if (buf == null) buf = new byte[8192];
                int r = in.read(buf, 0, (int) Math.min(buf.length, n));
                if (r < 0) throw new IOException("Unexpected end of donor file");
                s = r;
            }
            n -= s;
        }
    }

    private static String cstr(byte[] b, int off, int len) {
        int e = off; while (e < off + len && b[e] != 0) e++;
        return new String(b, off, e - off, StandardCharsets.UTF_8);
    }

    private static long parseOct(byte[] b, int off, int len) {
        long v = 0; boolean any = false;
        for (int i = off; i < off + len; i++) {
            if (b[i] >= '0' && b[i] <= '7') { v = v * 8 + (b[i] - '0'); any = true; }
            else if (any) break;
        }
        return v;
    }

    /** Minimal JSON parser (objects, arrays, strings, numbers, booleans, null). */
    static final class MiniJson {
        private final String s;
        private int i;
        private MiniJson(String s) { this.s = s; }

        static Object parse(String s) {
            MiniJson p = new MiniJson(s);
            Object v = p.value();
            p.ws();
            if (p.i != s.length()) throw new IllegalArgumentException("trailing data");
            return v;
        }

        private void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }

        private Object value() {
            ws();
            if (i >= s.length()) throw new IllegalArgumentException("eof");
            char c = s.charAt(i);
            if (c == '{') {
                i++;
                Map<String, Object> m = new LinkedHashMap<>();
                ws();
                if (s.charAt(i) == '}') { i++; return m; }
                while (true) {
                    ws();
                    String k = string();
                    ws();
                    if (s.charAt(i++) != ':') throw new IllegalArgumentException("expected :");
                    m.put(k, value());
                    ws();
                    char d = s.charAt(i++);
                    if (d == '}') return m;
                    if (d != ',') throw new IllegalArgumentException("expected ,");
                }
            }
            if (c == '[') {
                i++;
                List<Object> l = new ArrayList<>();
                ws();
                if (s.charAt(i) == ']') { i++; return l; }
                while (true) {
                    l.add(value());
                    ws();
                    char d = s.charAt(i++);
                    if (d == ']') return l;
                    if (d != ',') throw new IllegalArgumentException("expected ,");
                }
            }
            if (c == '"') return string();
            if (s.startsWith("true", i)) { i += 4; return Boolean.TRUE; }
            if (s.startsWith("false", i)) { i += 5; return Boolean.FALSE; }
            if (s.startsWith("null", i)) { i += 4; return null; }
            int st = i;
            while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
            if (st == i) throw new IllegalArgumentException("bad token at " + i);
            String num = s.substring(st, i);
            try { return Long.parseLong(num); } catch (NumberFormatException e) { return Double.parseDouble(num); }
        }

        private String string() {
            if (s.charAt(i) != '"') throw new IllegalArgumentException("expected string");
            i++;
            StringBuilder sb = new StringBuilder();
            while (true) {
                char c = s.charAt(i++);
                if (c == '"') return sb.toString();
                if (c == '\\') {
                    char e = s.charAt(i++);
                    switch (e) {
                        case 'n': sb.append('\n'); break;
                        case 't': sb.append('\t'); break;
                        case 'r': sb.append('\r'); break;
                        case 'b': sb.append('\b'); break;
                        case 'f': sb.append('\f'); break;
                        case 'u': sb.append((char) Integer.parseInt(s.substring(i, i + 4), 16)); i += 4; break;
                        default: sb.append(e);
                    }
                } else sb.append(c);
            }
        }
    }
}
