package com.mtz2bak.core;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Independent re-reader of a generated .bak: checks headers, tar checksums and that every
 *  component's SHA-1 matches the hash recorded in its metadata. Throws IOException on any problem. */
public final class BakVerifier {
    private static final Pattern HASH = Pattern.compile("\"hash\"\\s*:\\s*\"([0-9a-f]{40})\"");
    private static final Pattern META = Pattern.compile(".*/\\.data/meta/([^/]+)/([^/]+)\\.mrm");
    private static final Pattern CONTENT = Pattern.compile(".*/\\.data/content/([^/]+)/([^/]+)\\.mrc");

    public static String verify(File f) throws IOException {
        try (InputStream in = new BufferedInputStream(new FileInputStream(f), 1 << 16)) {
            String[] expect = {"MIUI BACKUP", "2", BakBuilder.PKG + " Themes", "-1", "0", "ANDROID BACKUP", "5", "0", "none"};
            for (String e : expect) {
                String line = readLine(in);
                if (!e.equals(line)) throw new IOException("Bad header line: '" + line + "' (expected '" + e + "')");
            }
            Map<String, String> metaHash = new HashMap<>();   // id -> hash
            Map<String, String> metaCode = new HashMap<>();   // id -> code
            Map<String, String> contentSha = new HashMap<>(); // id -> sha1
            int entries = 0, files = 0;
            boolean first = true;
            byte[] h = new byte[512];
            while (true) {
                readFully(in, h);
                boolean zero = true;
                for (byte b : h) if (b != 0) { zero = false; break; }
                if (zero) break;
                if (h[257] != 'u' || h[258] != 's' || h[259] != 't' || h[260] != 'a' || h[261] != 'r') throw new IOException("Bad tar magic");
                long chk = parseOct(h, 148, 6);
                long calc = 0;
                for (int i = 0; i < 512; i++) calc += (i >= 148 && i < 156) ? 32 : (h[i] & 0xff);
                if (chk != calc) throw new IOException("Bad tar checksum at entry " + entries);
                String name = cstr(h, 0, 100), prefix = cstr(h, 345, 155);
                String full = prefix.isEmpty() ? name : prefix + "/" + name;
                long size = parseOct(h, 124, 11);
                char type = (char) h[156];
                entries++;
                if (first) {
                    if (!full.equals("apps/" + BakBuilder.PKG + "/_manifest")) throw new IOException("_manifest must be the first entry");
                    first = false;
                }
                if (!full.startsWith("apps/" + BakBuilder.PKG + "/")) throw new IOException("Unexpected path: " + full);
                if (type == '0') {
                    files++;
                    Matcher mm = META.matcher(full), cm = CONTENT.matcher(full);
                    if (mm.matches()) {
                        if (size > (4 << 20)) throw new IOException("Meta too large: " + full);
                        byte[] b = new byte[(int) size];
                        readFully(in, b);
                        String txt = new String(b, StandardCharsets.UTF_8);
                        Matcher hm = HASH.matcher(txt);
                        if (!hm.find()) throw new IOException("No hash in " + full);
                        metaHash.put(mm.group(2), hm.group(1));
                        metaCode.put(mm.group(2), mm.group(1));
                        skip(in, pad(size));
                    } else if (cm.matches()) {
                        MessageDigest md = sha1();
                        long left = size; byte[] buf = new byte[1 << 16];
                        while (left > 0) {
                            int n = in.read(buf, 0, (int) Math.min(buf.length, left));
                            if (n < 0) throw new IOException("Truncated file: " + full);
                            md.update(buf, 0, n); left -= n;
                        }
                        contentSha.put(cm.group(2), BakBuilder.hex(md.digest()));
                        skip(in, pad(size));
                    } else {
                        skip(in, size + pad(size));
                    }
                } else if (type == '5') {
                    if (size != 0) throw new IOException("Directory with data: " + full);
                } else {
                    throw new IOException("Unsupported tar entry type '" + type + "' for " + full);
                }
            }
            if (first) throw new IOException("Empty archive");
            int comps = 0;
            for (Map.Entry<String, String> e : metaHash.entrySet()) {
                String id = e.getKey();
                if ("theme".equals(metaCode.get(id))) continue;      // theme-level hash = whole .mtz
                String sha = contentSha.get(id);
                if (sha == null) throw new IOException("Missing content for component " + metaCode.get(id));
                if (!sha.equals(e.getValue())) throw new IOException("Hash mismatch for component " + metaCode.get(id));
                comps++;
            }
            if (comps == 0) throw new IOException("No components in archive");
            return comps + " components, " + files + " files, all hashes OK";
        }
    }

    private static long pad(long size) { long r = size % 512; return r == 0 ? 0 : 512 - r; }

    private static MessageDigest sha1() throws IOException {
        try { return MessageDigest.getInstance("SHA-1"); } catch (Exception e) { throw new IOException(e); }
    }

    private static String readLine(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = in.read()) != '\n') {
            if (c < 0 || sb.length() > 300) throw new IOException("Bad header");
            sb.append((char) c);
        }
        return sb.toString();
    }

    private static void readFully(InputStream in, byte[] b) throws IOException {
        int o = 0;
        while (o < b.length) { int n = in.read(b, o, b.length - o); if (n < 0) throw new IOException("Unexpected end of file"); o += n; }
    }

    private static void skip(InputStream in, long n) throws IOException {
        while (n > 0) {
            long s = in.skip(n);
            if (s <= 0) { if (in.read() < 0) throw new IOException("Unexpected end of file"); s = 1; }
            n -= s;
        }
    }

    private static String cstr(byte[] b, int off, int len) {
        int e = off; while (e < off + len && b[e] != 0) e++;
        return new String(b, off, e - off, StandardCharsets.UTF_8);
    }

    private static long parseOct(byte[] b, int off, int len) throws IOException {
        long v = 0; boolean any = false;
        for (int i = off; i < off + len; i++) {
            if (b[i] >= '0' && b[i] <= '7') { v = v * 8 + (b[i] - '0'); any = true; }
            else if (any) break;
        }
        return v;
    }
}
