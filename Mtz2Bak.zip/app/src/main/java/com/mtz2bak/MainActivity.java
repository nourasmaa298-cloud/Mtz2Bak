package com.mtz2bak;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.mtz2bak.core.BakBuilder;
import com.mtz2bak.core.BakVerifier;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final int REQ_PICK = 1;
    private static final int REQ_SAVE = 2;
    private static final int REQ_ALL_FILES = 3;
    private static final int REQ_DONOR = 4;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    private File cachedMtz;
    private File donorFile;
    private String pickedName = "theme";

    private TextView fileLabel;
    private TextView donorLabel;
    private Button btnDonor;
    private TextView status;
    private ProgressBar bar;
    private Button btnPick;
    private Button btnDirect;
    private Button btnSave;
    private boolean busy = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cachedMtz = new File(getCacheDir(), "input.mtz");
        donorFile = new File(getCacheDir(), "donor.bak");
        donorFile.delete();
        buildUi();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        worker.shutdown();
    }

    // ------------------------------------------------------------------ UI
    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setPadding(0, dp(6), 0, dp(6));
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.START);
        return t;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(24), dp(18), dp(24));
        scroll.addView(root);

        root.addView(text("محوّل ثيمات MTZ إلى BAK", 22, true));
        root.addView(text(
                "قبل البدء (مرة واحدة فقط):\n"
                        + "١) من الإعدادات > عن الهاتف > النسخ الاحتياطي والاستعادة > نسخ احتياطي على الهاتف.\n"
                        + "٢) ألغِ تحديد كل شيء، ثم افتح «بيانات تطبيقات النظام الأخرى» واختر تطبيق «الثيمات» (Themes) فقط، وابدأ النسخ.\n"
                        + "٣) ارجع إلى هنا واتبع الخطوات بالأسفل.", 15, false));

        btnPick = new Button(this);
        btnPick.setText("١. اختر ملف الثيم (.mtz)");
        btnPick.setOnClickListener(v -> pickFile());
        root.addView(btnPick);

        fileLabel = text("لم يتم اختيار ملف بعد", 14, false);
        root.addView(fileLabel);

        btnDonor = new Button(this);
        btnDonor.setText("اختياري: نسخة أصلية تحوي نفس الثيم (للحقوق)");
        btnDonor.setOnClickListener(v -> pickDonor());
        root.addView(btnDonor);

        donorLabel = text("إن كانت عندك نسخة احتياطية حقيقية فيها هذا الثيم نفسه (نزّلته من المتجر)، اخترها ليأخذ التطبيق منها ملف الحقوق الأصلي. "
                + "لا يعمل مع ثيم لا توجد له حقوق في نسخة أصلية.", 13, false);
        root.addView(donorLabel);

        btnDirect = new Button(this);
        btnDirect.setText("٢. تحويل واستبدال النسخة الاحتياطية تلقائياً");
        btnDirect.setOnClickListener(v -> onDirectClicked());
        root.addView(btnDirect);

        root.addView(text("يستبدل ملف Themes(com.android.thememanager).bak في أحدث نسخة داخل MIUI/backup/AllBackup. "
                + "يحتاج إذن «الوصول إلى كل الملفات» وسيطلبه التطبيق.", 13, false));

        btnSave = new Button(this);
        btnSave.setText("أو: تحويل وحفظ الملف في مكان أختاره");
        btnSave.setOnClickListener(v -> onSaveClicked());
        root.addView(btnSave);

        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setIndeterminate(true);
        bar.setVisibility(View.INVISIBLE);
        root.addView(bar);

        status = text("", 14, false);
        root.addView(status);

        root.addView(text(
                "بعد نجاح التحويل:\n"
                        + "• افتح النسخ الاحتياطي والاستعادة > الاستعادة من الهاتف > اختر أحدث نسخة > الثيمات > استعادة.\n"
                        + "• ثم افتح تطبيق الثيمات واذهب إلى «الثيمات الخاصة بي / المحلية» وطبّق الثيم.\n"
                        + "• الاستعادة تضيف الثيم فقط ولا تحذف ثيماتك الحالية.", 14, false));

        setContentView(scroll);
    }

    private void setBusy(final boolean b) {
        ui.post(() -> {
            busy = b;
            bar.setVisibility(b ? View.VISIBLE : View.INVISIBLE);
            btnPick.setEnabled(!b);
            btnDonor.setEnabled(!b);
            btnDirect.setEnabled(!b);
            btnSave.setEnabled(!b);
        });
    }

    private void setStatus(final String s) {
        ui.post(() -> status.setText(s));
    }

    private void toast(final String s) {
        ui.post(() -> Toast.makeText(MainActivity.this, s, Toast.LENGTH_LONG).show());
    }

    // ------------------------------------------------------------------ picking
    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_PICK);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) onPicked(data.getData());
        } else if (requestCode == REQ_DONOR) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) onDonorPicked(data.getData());
        } else if (requestCode == REQ_SAVE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) convert(false, data.getData());
        } else if (requestCode == REQ_ALL_FILES) {
            if (Environment.isExternalStorageManager()) {
                convert(true, null);
            } else {
                toast("لم يتم منح إذن الوصول إلى كل الملفات. استخدم زر «حفظ في مكان أختاره» بدلاً من ذلك.");
            }
        }
    }

    private String queryName(Uri uri) {
        String name = null;
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) name = c.getString(idx);
            }
        } catch (Exception ignored) {
        }
        if (name == null || name.isEmpty()) {
            String p = uri.getLastPathSegment();
            name = p == null ? "theme.mtz" : p;
        }
        return name;
    }

    private void onPicked(final Uri uri) {
        final String name = queryName(uri);
        setBusy(true);
        setStatus("جارٍ قراءة الملف…");
        worker.execute(() -> {
            try {
                try (InputStream in = getContentResolver().openInputStream(uri);
                     OutputStream out = new FileOutputStream(cachedMtz)) {
                    if (in == null) throw new IOException("تعذّر فتح الملف");
                    byte[] buf = new byte[1 << 16];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                }
                pickedName = name;
                final long mb = cachedMtz.length() / (1024 * 1024);
                ui.post(() -> fileLabel.setText("الملف المختار: " + name + "  (" + mb + " MB)"));
                setStatus(name.toLowerCase().endsWith(".mtz") ? "" : "تنبيه: الملف لا ينتهي بـ .mtz، سأحاول قراءته على أي حال.");
            } catch (Throwable t) {
                pickedName = "theme";
                cachedMtz.delete();
                ui.post(() -> fileLabel.setText("لم يتم اختيار ملف بعد"));
                setStatus("فشلت قراءة الملف: " + t.getMessage());
            } finally {
                setBusy(false);
            }
        });
    }

    private void pickDonor() {
        if (busy) return;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_DONOR);
    }

    private void onDonorPicked(final Uri uri) {
        final String name = queryName(uri);
        setBusy(true);
        setStatus("جارٍ قراءة النسخة الأصلية…");
        worker.execute(() -> {
            try {
                try (InputStream in = getContentResolver().openInputStream(uri);
                     OutputStream out = new FileOutputStream(donorFile)) {
                    if (in == null) throw new IOException("تعذّر فتح الملف");
                    byte[] buf = new byte[1 << 16];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                }
                final long mb = donorFile.length() / (1024 * 1024);
                ui.post(() -> donorLabel.setText("النسخة الأصلية المختارة: " + name + "  (" + mb + " MB)"));
                setStatus("");
            } catch (Throwable t) {
                donorFile.delete();
                setStatus("فشلت قراءة النسخة الأصلية: " + t.getMessage());
            } finally {
                setBusy(false);
            }
        });
    }

    // ------------------------------------------------------------------ actions
    private boolean haveInput() {
        if (!cachedMtz.exists() || cachedMtz.length() == 0) {
            toast("اختر ملف .mtz أولاً");
            return false;
        }
        return true;
    }

    private void onDirectClicked() {
        if (busy || !haveInput()) return;
        if (!Environment.isExternalStorageManager()) {
            toast("امنح التطبيق إذن «الوصول إلى كل الملفات» ثم ارجع.");
            Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            try {
                startActivityForResult(i, REQ_ALL_FILES);
            } catch (Exception e) {
                startActivityForResult(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION), REQ_ALL_FILES);
            }
            return;
        }
        convert(true, null);
    }

    private void onSaveClicked() {
        if (busy || !haveInput()) return;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_TITLE, BakBuilder.BAK_FILE_NAME);
        startActivityForResult(i, REQ_SAVE);
    }

    // ------------------------------------------------------------------ conversion
    private BakBuilder.ManifestInfo readManifestInfo() {
        BakBuilder.ManifestInfo mi = BakBuilder.ManifestInfo.defaults();
        mi.sdkInt = Build.VERSION.SDK_INT;
        try {
            PackageManager pm = getPackageManager();
            PackageInfo pi = pm.getPackageInfo(BakBuilder.PKG, PackageManager.GET_SIGNING_CERTIFICATES);
            SigningInfo si = pi.signingInfo;
            Signature[] sigs = null;
            if (si != null) {
                sigs = si.hasMultipleSigners() ? si.getApkContentsSigners() : si.getSigningCertificateHistory();
                if (sigs == null || sigs.length == 0) sigs = si.getApkContentsSigners();
            }
            if (sigs != null && sigs.length > 0) {
                List<String> hex = new ArrayList<>();
                for (Signature s : sigs) hex.add(BakBuilder.hex(s.toByteArray()));
                mi.signaturesHex = hex;
                mi.versionCode = pi.getLongVersionCode();
                String installer = null;
                try {
                    installer = pm.getInstallSourceInfo(BakBuilder.PKG).getInstallingPackageName();
                } catch (Exception ignored) {
                }
                mi.installer = installer == null ? "" : installer;
            }
        } catch (Exception ignored) {
            // Themes app not visible/installed: fall back to the values from a real HyperOS backup.
        }
        return mi;
    }

    private static String stripExt(String n) {
        int d = n.lastIndexOf('.');
        return d > 0 ? n.substring(0, d) : n;
    }

    private void convert(final boolean direct, final Uri saveUri) {
        if (busy) return;
        setBusy(true);
        setStatus("جارٍ التحويل…");
        worker.execute(() -> {
            File tmp = new File(getCacheDir(), "output.bak");
            try {
                BakBuilder.ManifestInfo mi = readManifestInfo();
                BakBuilder.Result r;
                try (OutputStream o = new FileOutputStream(tmp)) {
                    r = BakBuilder.build(cachedMtz, stripExt(pickedName), o, mi, msg -> setStatus("جارٍ التحويل: " + msg),
                            donorFile.exists() ? donorFile : null);
                }
                setStatus("جارٍ التحقق من سلامة الملف…");
                String check = BakVerifier.verify(tmp);

                String where;
                if (direct) where = installDirect(tmp);
                else where = saveTo(tmp, saveUri);

                StringBuilder sb = new StringBuilder();
                sb.append("✅ تم بنجاح!\nالثيم: ").append(r.title).append('\n');
                sb.append("التحقق: ").append(check).append('\n');
                if (donorFile.exists()) {
                    if (r.donorUsed && r.rightsIncluded) sb.append("تم نسخ ملف الحقوق وهوية الثيم الأصلية من النسخة المختارة.\n");
                    else if (r.donorUsed) sb.append("النسخة المختارة تحوي الثيم لكن بدون ملف حقوق له.\n");
                    else sb.append("النسخة المختارة لا تحوي هذا الثيم نفسه، فلم تُستخدم.\n");
                }
                sb.append("المكان: ").append(where).append('\n');
                if (!r.warnings.isEmpty()) sb.append("ملاحظات: ").append(r.warnings).append('\n');
                sb.append("\nالآن نفّذ الاستعادة من تطبيق النسخ الاحتياطي.");
                setStatus(sb.toString());
            } catch (Throwable t) {
                setStatus("❌ فشل التحويل: " + t.getMessage());
            } finally {
                tmp.delete();
                setBusy(false);
            }
        });
    }

    private String saveTo(File src, Uri uri) throws IOException {
        try (InputStream in = new FileInputStream(src);
             OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
            if (out == null) throw new IOException("تعذّر الكتابة في المكان المختار");
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
        return uri.toString() + "\n(تأكد أن اسم الملف هو " + BakBuilder.BAK_FILE_NAME + " ثم انسخه إلى مجلد النسخة داخل MIUI/backup/AllBackup)";
    }

    private String installDirect(File src) throws IOException {
        File base = new File(Environment.getExternalStorageDirectory(), "MIUI/backup/AllBackup");
        File[] dirs = base.listFiles(File::isDirectory);
        if (dirs == null || dirs.length == 0) {
            throw new IOException("لم أجد مجلد " + base.getPath() + "\nأنشئ أولاً نسخة احتياطية لتطبيق الثيمات فقط ثم أعد المحاولة.");
        }
        Arrays.sort(dirs, new Comparator<File>() {
            @Override
            public int compare(File a, File b) {
                return Long.compare(b.lastModified(), a.lastModified());
            }
        });
        File target = null;
        for (File d : dirs) {
            File cand = new File(d, BakBuilder.BAK_FILE_NAME);
            if (cand.isFile()) {
                target = cand;
                break;
            }
        }
        if (target == null) {
            throw new IOException("لم أجد الملف " + BakBuilder.BAK_FILE_NAME + " داخل " + base.getPath()
                    + "\nأنشئ أولاً نسخة احتياطية لتطبيق الثيمات فقط (انظر التعليمات بالأعلى).");
        }
        File next = new File(target.getParentFile(), BakBuilder.BAK_FILE_NAME + ".new");
        try (InputStream in = new FileInputStream(src); OutputStream out = new FileOutputStream(next)) {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
        if (next.length() != src.length()) {
            next.delete();
            throw new IOException("فشل نسخ الملف إلى المجلد الهدف");
        }
        if (!target.delete()) {
            next.delete();
            throw new IOException("تعذّر استبدال الملف القديم في " + target.getParentFile().getPath());
        }
        if (!next.renameTo(target)) {
            next.delete();
            throw new IOException("تعذّر إعادة تسمية الملف الجديد");
        }
        return target.getPath();
    }
}
